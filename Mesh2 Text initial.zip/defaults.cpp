#include "defaults.h"

// Define global variables
String callsign = "NOCALL";
long frequency = 915000000;  // Frequency in Hz
int spreadingFactor = 7;
int bandwidth = 125000;      // Bandwidth in Hz
int codingRate = 5;
