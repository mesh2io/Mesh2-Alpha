#ifndef BATTERY_H
#define BATTERY_H

// Function declarations
float readBatteryVoltage();
int calculateBatteryPercentage(float voltage);

#endif // BATTERY_H
