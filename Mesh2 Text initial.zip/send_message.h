#ifndef SEND_MESSAGE_H
#define SEND_MESSAGE_H

#include <Arduino.h>

// Function declarations
void fetchLoRaUserList();
void handleSendMessage();

#endif // SEND_MESSAGE_H
