#ifndef MESSAGE_RECEIVE_H
#define MESSAGE_RECEIVE_H

void receiveLoRaMessages();
bool checkNewMessage();
void clearNewMessageFlag();

#endif
