#ifndef DISPLAY_HELPER_H
#define DISPLAY_HELPER_H

void displayMessage(const char *message);

#endif // DISPLAY_HELPER_H
