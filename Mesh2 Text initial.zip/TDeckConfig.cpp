#include "TDeckConfig.h"

LGFX_S3TDeck display; // Instantiate the display object