#include "cpins.h"

// Define settings file paths
const char *SETTINGS_FILE = "/settings.txt";
const char *MESSAGES_FILE = "/messages.txt";
