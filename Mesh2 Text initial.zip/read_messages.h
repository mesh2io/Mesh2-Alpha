
#include "statusbar.h"
#ifndef READ_MESSAGES_H
#define READ_MESSAGES_H

void readMessages();

#endif
